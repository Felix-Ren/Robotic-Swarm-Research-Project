function parsave(delta,N)
    fname = ['optimalRingDistributionDelta',num2str(delta),'N',num2str(N),'.mat'];
    save(fname);
end
